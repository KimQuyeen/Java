package modul;

public class data {
	
public static	String username;
public static  String path;
public static String id;
public static int cid;
}
